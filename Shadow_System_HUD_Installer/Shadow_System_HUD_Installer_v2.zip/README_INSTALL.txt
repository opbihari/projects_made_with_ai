======================================================================
          SHADOW SYSTEM HUD v2.0 - WINDOWS 11 INSTALLER GUIDE
======================================================================

OPTION 1: 1-CLICK AUTOMATIC INSTALLER (RECOMMENDED)
----------------------------------------------------------------------
1. Right-click Shadow_System_HUD_Installer_v2.zip and click "Extract All...".
2. Double-click:  Install_Shadow_System_HUD.bat
   - Installs directly inside the terminal with live progress [1/5]..[5/5]
   - Installs to: %LOCALAPPDATA%\Programs\ShadowSystemHUD
   - Creates a Desktop shortcut ("Shadow System HUD") with a custom icon
   - Creates a Start Menu shortcut & registers in Windows Installed Apps
   - Configures Windows Startup auto-launch (no console window flash)
   - Auto-detects MinGW64 / GCC and Lively Wallpaper
   - Automatically launches the Shadow System HUD on your screen!

OPTION 2: BUILD A STANDALONE NATIVE .EXE FILE
----------------------------------------------------------------------
- Double-click:  Build_Standalone_EXE.bat
- Compiles %LOCALAPPDATA%\Programs\ShadowSystemHUD\ShadowSystemHUD.exe
  and links your Desktop & Start Menu shortcuts directly to it.

UNINSTALLING
----------------------------------------------------------------------
- Double-click Uninstall_Shadow_System_HUD.bat (or uninstall directly
  from Windows 11 Settings -> Apps -> Installed Apps -> Shadow System HUD).
======================================================================
